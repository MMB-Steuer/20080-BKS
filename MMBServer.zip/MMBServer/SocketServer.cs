﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Xml;
/* !!! TODO !!!
 * Command Change Event
 * return BoardStatus
 * Fehlerrückgabe TCPIP checken
 */
namespace MMBServer
{
    public class SocketServer
    {
        private static SocketServer instance;
        private IPAddress IpAddress = null;
        private int Port = 0;
        private TcpListener listner = null;
        private TcpClient tcpClient = null;
        private NetworkStream stream = null;
        private byte[] buffer = null;
        private byte _lastCMD = 0;
        private MMBConfig _config;
        public static SocketServer getInstance()
        {
            if (instance == null) { instance = new SocketServer(); }
            return instance;
        }
        // Create Delete Telegram
        public static XmlDocument DeleteTelegram(ManufactoringJob job)
        {
            LogService.getInstance().create(LogService._INFORMATION, "SocketServer.DeleteTelegram", "");
            XmlDocument xml = new XmlDocument();
            XmlNode rootNode = xml.CreateElement("Root");
            XmlNode TelegrammNode = xml.CreateElement("Telegram");
            XmlAttribute TelegrammName = xml.CreateAttribute("Name");
            TelegrammName.Value = "Delete";
            TelegrammNode.Attributes.Append(TelegrammName);
            xml.AppendChild(rootNode);
            rootNode.AppendChild(TelegrammNode);
            XmlNode VersionNode = xml.CreateElement("Version");
            VersionNode.InnerText = "5";
            TelegrammNode.AppendChild(VersionNode);
            XmlNode UIDNode = xml.CreateElement("UID");
            UIDNode.InnerText = job.UID + ""; ;
            TelegrammNode.AppendChild(UIDNode);
            return xml;
        }
        private SocketServer()
        {
        }
        // Listen for Commands from SBS
        public void listen()
        {
            try
            {
                MMBConfig _config = MMBConfig.getInstance();
                this.IpAddress = IPAddress.Parse(_config.TcpSeverAdress);
                this.Port = int.Parse(_config.TcpPort);
                Console.WriteLine("XMLServer: " + _config.XMLServerAdress + " - XMLServerPort: " + _config.XMLSeverPort.ToString());
                while (true)
                {
                    this.listner = new TcpListener(this.IpAddress, this.Port);
                    this.listner.Start();
                    // awaiting TCP Connection from BKS
                    LogService.getInstance().create(LogService._DEBUG, "TcpIpServer", "Warte auf Verbindung");
                    this.tcpClient = this.listner.AcceptTcpClient();
                    this.stream = tcpClient.GetStream();
                    this.buffer = exampleByteArray();
                    // on this point a TCP Connection is established
                    LogService.getInstance().create(LogService._DEBUG, "TcpIpServer", "Verbindung hergestellt");
                    while (true)
                    {
                        try
                        {
                            //LogService.getInstance().create(LogService._INFORMATION, "connection established");
                            this.stream.ReadTimeout = 15000;            // Time Out Timer for Reader from Stream
                            this.stream.Read(buffer, 0, _config.MMBtcpPackageSize);     // read Data from TCPStream
                            string UID = this.receiveUID(buffer);
                            /*
                            _config.PersonalNumber = this.receivePersonalNumber(buffer);
                            _config.PersonalPassword = this.receivePersonalPassword(buffer);
                            */
                            if (buffer[1] % 2 == 0)
                            {
                                LogEntry.cleanNotifications();
                            }
                            // For Developing Purposes
                            //Console.WriteLine("CMD: " + buffer[0] + " | Count: " + buffer[_config.MmbtcpPackageOffSetCount] + " | pw: " + _config.PersonalPassword + " | user: " + _config.PersonalNumber + " | uid: " + UID);
                            //LogService.getInstance().create(LogService._INFORMATION, "CMD: " + buffer[0] + " | Count: " + buffer[_config.MmbtcpPackageOffSetCount] + " | pw: " + _config.PersonalPassword + " | user: " + _config.PersonalNumber + " | uid: " + UID);
                            //buffer[0] = (byte)1;
                            if (buffer[0] != _lastCMD)
                            {
                                // muss getested werden, ob das letzte commando anders ist als das aktuelle
                                Console.WriteLine("CMD: " + buffer[0].ToString());
                                LogService.getInstance().create(LogService._INFORMATION, "CMD CHANGED FROM " + _lastCMD.ToString() + " to " + buffer[0].ToString());
                                _lastCMD = buffer[0];

                                switch (buffer[0])
                                {
                                    case 0:
                                        // CMD = 0 == noAction
                                        buffer = this.resetData(buffer);
                                        break;
                                    case 1:  // CMD = 1 == Request Manufactoring Data
                                        buffer = this.requestManufactoringData(buffer);
                                        break;
                                    case 2:
                                        // CMD = 2 == returnBoardStatus
                                        buffer = this.returnBKSBoardStatus(buffer);
                                        break;
                                    default: // Reset Data
                                        buffer = this.resetData(buffer);
                                        break;
                                }
                            }else
                            {
                                buffer[0] = (byte)0;
                            }
                            //LogService.getInstance().create(LogService._INFORMATION, "CMD CHANGED FROM " + _lastCMD.ToString() + " to " + buffer[0].ToString());
                            // Counter erhöhen
                            this.buffer[2] = (byte)(this.buffer[2] + 1);
                            this.stream.Write(buffer, 0, _config.MMBtcpPackageSize);
                        }
                        // ThreadAbort Extion // required for Thread Management
                        catch (ThreadAbortException ex)
                        {
                            LogService.getInstance().create(ex);
                            stream.Close();
                            tcpClient.Close();
                            listner.Stop();
                            throw ex;
                            break;
                        }
                        // All other Exceptions
                        catch (Exception ex)
                        {
                            LogService.getInstance().create(ex);
                            listner.Stop();
                            listner = null;
                            break;
                        }
                    }
                }
            }
            // ThreadAbort Extion // required for Thread Management
            catch (ThreadAbortException ex)
            {
                LogService.getInstance().create(ex);
            }
            // all other Exceptions
            catch (Exception ex)
            {
                LogService.getInstance().create(ex);
            }
        }
        // Requesting Manufactoring Data from BKS Server
        public byte[] requestManufactoringData(byte[] buffer)
        {
            SocketClient socket = null;
            bool isOk = false;
            string UID = this.receiveUID(buffer);
            _config = MMBConfig.getInstance();
            try
            {
                ManufactoringDataRequest x = new ManufactoringDataRequest();
                x.UID = int.Parse(UID);
                XmlDocument request = x.toXML(this.receivePersonalNumber(buffer), this.receivePersonalPassword(buffer));
                XmlArchiv.CreateToDB(XmlArchiv.TRIGGER_SENDMANUFACTORINGDATAREQUEST, request.OuterXml, XmlArchiv.COMMENT_OUTGOING);
                //receive SocketClient
                socket = SocketClient.getInstance();
                socket.initCon(_config.XMLServerAdress, _config.XMLSeverPort.ToString());
                byte[] requestdata = Encoding.Default.GetBytes(request.OuterXml);
                // Xml an BKS Server senden
                string responseString = socket.sendMessage(requestdata);
                XmlDocument resXml = new XmlDocument();
                // BKS antwort in XML wandeln
                resXml.LoadXml(responseString);
                XmlArchiv.CreateToDB(XmlArchiv.TRIGGER_ANSWERMANUFACTORINGDATAREQUEST, resXml.OuterXml, XmlArchiv.COMMENT_INCOMING);
                List<ManufactoringJob> list = ManufactoringJob.convertFromManufactoringData(resXml);
                XmlNode telegramnote = resXml.SelectSingleNode("/Root/Telegram");
                LogService.getInstance().create(LogService._INFORMATION, "anserwer " + resXml.OuterXml);
                // check for Error Tag in Answer
                if (resXml.SelectSingleNode("/Root/Telegram").Attributes["Name"].Value.Equals("Error"))
                {
                    isOk = false;
                    buffer[0] = (byte)(buffer[0] = (byte)21);
                    return buffer;
                }
                // Iterate Jobs
                foreach (ManufactoringJob j in list)
                {
                    try
                    {
                        Console.WriteLine("Job Created");
                        try
                        {
                            j.save();
                            socket.sendMessage(Encoding.Default.GetBytes(j.DeleteTelegram().OuterXml));
                        }
                        catch (Exception ex)
                        {
                        }
                    }
                    catch (Exception ex)
                    {
                    }
                }
            }
            catch (Exception ex)
            {
                LogService.getInstance().create(ex);
                buffer[0] = (byte)21;
                return buffer;
            }
            if (isOk == false)
            {
                buffer[0] = (byte)21;
            }
            buffer[0] = (byte)11;
            return buffer;
        }
        // return Boardstatus to BKSServer
        private byte[] returnBKSBoardStatus(byte[] _data)
        {
            LogService.getInstance().create(LogService._INFORMATION, "return BKS Board");
            try
            {
                bool isOk = true;
                SocketClient _socket = null;
                MMBConfig _config = MMBConfig.getInstance();
                LogService.getInstance().create(LogService._INFORMATION, "return BKS Board");

                try
                {
                    _socket = SocketClient.getInstance();
                    _socket.initCon(_config.XMLServerAdress, _config.XMLSeverPort.ToString());
                }
                catch(Exception ex)
                {
                    LogService.getInstance().create(ex);
                    _data[0] = (byte)22;
                    //return _data;
                } 

                // Virtuelles Board erstellen
                BKSBoard board = new BKSBoard();
                // Virtuellem Board DSC mitteilen
                Console.WriteLine("DSC : " + this.receiveUID(_data));
                board.DSC = this.receiveUID(_data);
                if (String.IsNullOrEmpty(board.DSC))
                {
                    LogService.getInstance().create(LogService._ERROR, "Board DSC not set ");
                    _data[0] = (byte)22;
                }
                // Virtuelles Board mit Jobs befüllen
                board.getData();
                XmlDocument xml = board.getReceipt(this.receivePersonalNumber(buffer), this.receivePersonalPassword(buffer));
                XmlArchiv.CreateToDB(XmlArchiv.TRIGGER_BOARDRECEIPT, xml.OuterXml, XmlArchiv.COMMENT_OUTGOING);
                byte[] requestdata = Encoding.Default.GetBytes(xml.OuterXml);
                string responseString = "";
                try
                {
                    responseString = _socket.sendMessage(requestdata);
                    board.deleteJobsFromDB();
                }
                catch (Exception ex)
                {
                    LogService.getInstance().create(ex);
                }
                XmlDocument responseXML = new XmlDocument();

                //TODO Antwort auf Fehler checken wenn kein Fehler dann DAten aus DB löschen
                try
                {
                    responseXML.LoadXml(responseString);
                    XmlArchiv.CreateToDB(XmlArchiv.TRIGGER_ANSWERöBOARDRECEIPT, responseXML.InnerText, XmlArchiv.COMMENT_INCOMING);
                    ManufactoringJob.convertFromManufactoringData(responseXML).ForEach(x =>
                    {
                        x.save();
                    });

                    if (responseXML.SelectSingleNode("/Root/Telegram").Attributes["Name"].Value.Equals("Error"))
                    {
                        isOk = false;
                        buffer[0] = (byte)(buffer[0] = (byte)22);
                        return buffer;
                    }
                }
                catch (Exception ex)
                {

                }
            }catch (Exception ex)
            {
                LogService.getInstance().create(ex);
                _data[0] = (byte)22;
                return _data;
            }

            _data[0] = (byte)12;
            return _data;
        }
        // old Version return jobStatus to BKSServer
        public byte[] jobFinished(byte[] buffer)
        {
            MMBConfig _config = MMBConfig.getInstance();
            LogService.getInstance().create(LogService._INFORMATION, "SocketServer.JobFinished", "");
            SocketClient socket;

            bool isOk = true;
            try
            {
                List<ManufactoringJob> list = ManufactoringJob.getAllJobs();
                LogService.getInstance().create(LogService._INFORMATION, "Found Jobns: " + list.Count);
                int UID = int.Parse(this.receiveUID(buffer));
                LogService.getInstance().create(LogService._INFORMATION, "UID: " + UID);
                ManufactoringJob j = list.FirstOrDefault(x => x.UID == UID);
                if (j == null)
                {
                    LogService.getInstance().create(LogService._INFORMATION, "JOB NOT FOUND jobfinished");
                    buffer[0] = (byte)22;
                    throw new Exception("not found");
                }
                XmlDocument receipt = j.Receipt(this.receivePersonalNumber(buffer));
                byte[] requestdata = Encoding.Default.GetBytes(receipt.OuterXml);
                LogService.getInstance().create(LogService._INFORMATION, receipt.OuterXml);
                socket = SocketClient.getInstance();
                socket.initCon(_config.XMLServerAdress, _config.XMLSeverPort.ToString());
                string responseString = socket.sendMessage(requestdata);
                LogService.getInstance().create(LogService._INFORMATION, responseString);
                j.delete();
            }
            catch (InvalidCastException ex)
            {

            }
            catch (Exception ex)
            {
                LogService.getInstance().create(ex);
                buffer[0] = (byte)22;
                return buffer;
            }
            buffer[0] = (byte)22;
            return buffer;
        }
        // reset DataBuffer to default
        private byte[] resetData(byte[] buffer)
        {
            buffer[0] = (byte)0;
            for (int i = 2; i < MMBConfig.getInstance().MMBtcpPackageSize; i++)
            {
                buffer[i] = Convert.ToByte((char)' ');
            }
            return buffer;
        }
        // created Example empty byteArray for Test Purposes
        private byte[] exampleByteArray()
        {
            byte[] buffer = new byte[MMBConfig.getInstance().MMBtcpPackageSize];
            buffer[0] = (byte)0;
            buffer[1] = (byte)0;
            for (int i = 2; i < buffer.Length; i++)
            {
                buffer[i] = Convert.ToByte((char)' ');
            }

            return buffer;
        }
        // print bytearray in Console
        private void printData(byte[] data)
        {
            byte cmd = data[0];
            byte counter = data[1];
            string UID = System.Text.ASCIIEncoding.ASCII.GetString(data, 2, 10);
            Console.WriteLine("Counter :" + counter + " | cmd: " + cmd + " | uid: " + UID);
        }
        // get UID out of the buffer
        private string receiveUID(byte[] buffer)
        {
            for (int i = 0; i < 10; i++)
            {
                if (buffer[i+2] == 0)
                {
                    buffer[i + 2] = Convert.ToByte((char)' ');
                }
            }
            string UID = System.Text.ASCIIEncoding.ASCII.GetString(buffer, 2, 10);
            return UID;
        }
        // get PersonalNumber out of the buffer
        private string receivePersonalNumber(byte[] buffer)
        {
            return System.Text.ASCIIEncoding.ASCII.GetString(buffer, 12, 10).Trim();
        }
        // get PersonalPassword out of the buffer
        private string receivePersonalPassword(byte[] buffer)
        {
            return System.Text.ASCIIEncoding.ASCII.GetString(buffer, 22, 10).Trim();
        }
        // Dispose Method required for Thread Management
        public void dispose()
        {

            if (this.stream != null)
                this.stream.Close();

            if (this.tcpClient != null)
                this.tcpClient.Close();

            if (this.listner != null)
                listner.Stop();
        }
        // Check that the Data is Valid and plausibel
    }
}
